# Among Us - Always Impostor (Zygisk Magisk Module)

## What this does
Hooks `PlayerControl::RpcSetRole` in libil2cpp.so at runtime.
Every time the game tries to assign you a role, it intercepts the call
and forces `roleType = 1` (Impostor) before it executes.
Works silently every round, no manual scanning needed.

---

## How to build

### Prerequisites (on a PC)
1. Install **Android NDK r25c** or newer
   - Download: https://developer.android.com/ndk/downloads
2. Install **CMake 3.18+**
3. Download **Dobby** prebuilt for arm64-v8a:
   - https://github.com/jmpews/Dobby/releases
   - Get `libdobby.a` for `arm64-v8a`
   - Place it at: `libs/arm64-v8a/libdobby.a`
   - Also get `dobby.h` and place it at: `src/dobby.h`

### Build steps
```bash
# Set your NDK path
export NDK=/path/to/android-ndk-r25c

# Build for arm64-v8a (most modern Android phones)
mkdir build && cd build
cmake .. \
  -DCMAKE_TOOLCHAIN_FILE=$NDK/build/cmake/android.toolchain.cmake \
  -DANDROID_ABI=arm64-v8a \
  -DANDROID_PLATFORM=android-26 \
  -DCMAKE_BUILD_TYPE=Release

make -j4

# The output is: build/libimpostor.so
```

### Package as Magisk module
```bash
# Create the zip structure
mkdir -p package/zygisk

# Copy the compiled .so
cp build/libimpostor.so package/zygisk/arm64-v8a.so

# Copy module files
cp module.prop package/
cp customize.sh package/

# Create dummy files Magisk needs
touch package/zygisk/arm64-v8a.so  # already done above

# Zip it up
cd package
zip -r ../ImpostorMod.zip .
cd ..
```

### Install on phone
1. Open **Magisk** app
2. Tap **Modules** tab
3. Tap **Install from storage**
4. Select `ImpostorMod.zip`
5. Reboot when prompted
6. Launch Among Us — you're always Impostor 🎉

---

## No PC? Use GitHub Actions (free)

If you don't have a PC, you can build this for free using GitHub:

1. Create a free GitHub account
2. Create a new repository, upload all these files
3. Create `.github/workflows/build.yml` with this content:

```yaml
name: Build Zygisk Module
on: [push]
jobs:
  build:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3
      - name: Setup NDK
        uses: nttld/setup-ndk@v1
        with:
          ndk-version: r25c
      - name: Download Dobby
        run: |
          mkdir -p libs/arm64-v8a
          wget -O libs/arm64-v8a/libdobby.a \
            https://github.com/jmpews/Dobby/releases/download/alpha/libdobby_arm64.a
          wget -O src/dobby.h \
            https://raw.githubusercontent.com/jmpews/Dobby/master/include/dobby.h
      - name: Build
        run: |
          mkdir build && cd build
          cmake .. \
            -DCMAKE_TOOLCHAIN_FILE=$ANDROID_NDK_HOME/build/cmake/android.toolchain.cmake \
            -DANDROID_ABI=arm64-v8a \
            -DANDROID_PLATFORM=android-26 \
            -DCMAKE_BUILD_TYPE=Release
          make -j4
      - name: Package
        run: |
          mkdir -p package/zygisk
          cp build/libimpostor.so package/zygisk/arm64-v8a.so
          cp module.prop package/
          cp customize.sh package/
          cd package && zip -r ../ImpostorMod.zip .
      - name: Upload artifact
        uses: actions/upload-artifact@v3
        with:
          name: ImpostorMod
          path: ImpostorMod.zip
```

4. Push to GitHub → Actions tab → download `ImpostorMod.zip` when done
5. Transfer zip to phone → install via Magisk

---

## File structure of final zip
```
ImpostorMod.zip
├── module.prop
├── customize.sh
└── zygisk/
    └── arm64-v8a.so   ← compiled hook library
```

---

## Troubleshooting
- **Game crashes on launch:** The offset `0x23B57FC` may have changed if the game updated.
  Check logcat: `adb logcat -s ImpostorMod` to see hook status.
- **Still getting Crewmate:** The hook fired but `g_localPlayer` detection failed.
  This can happen if you're not the first `RpcSetRole` call. The fix is to also
  hook `PlayerControl::Start()` to capture LocalPlayer earlier — open an issue.
- **Magisk says module incompatible:** Make sure Zygisk is ENABLED in Magisk settings.
