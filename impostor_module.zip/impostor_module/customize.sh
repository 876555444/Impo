#!/system/bin/sh
# Among Us Always Impostor - Magisk Module Installer

SKIPUNZIP=1

# Extract files
unzip -o "$ZIPFILE" 'zygisk/*' -d "$MODPATH" >&2
unzip -o "$ZIPFILE" 'module.prop' -d "$MODPATH" >&2

# Set permissions
set_perm_recursive "$MODPATH" root root 0755 0644
