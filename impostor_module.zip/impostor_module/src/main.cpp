#include <cstdint>
#include <cstring>
#include <cstdio>
#include <unistd.h>
#include <pthread.h>
#include <android/log.h>
#include <sys/mman.h>
#include <dlfcn.h>
#include "zygisk.hpp"
#include "dobby.h"

#define TAG "ImpostorMod"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO,  TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, TAG, __VA_ARGS__)

// ── Offsets from dump.cs ─────────────────────────────────────────────────────
// NetworkedPlayerInfo fields:
//   0x35 = PlayerId  (uint8)
//   0x38 = ClientId  (int32)
//   0x50 = RoleType  (int16  — RoleTypes enum)
//   0x64 = Disconnected (bool)
//   0x78 = IsDead    (bool)
//   0x80 = _object   (PlayerControl*)
//
// PlayerControl static:
//   PlayerControl::LocalPlayer  static field offset 0x0 in static storage
//
// RoleTypes enum:
//   Crewmate = 0, Impostor = 1

#define OFFSET_PLAYERID      0x35
#define OFFSET_ROLETYPE      0x50
#define OFFSET_DISCONNECTED  0x64
#define OFFSET_ISDEAD        0x78
#define OFFSET_PC_OBJECT     0x80

// RpcSetRole offset from dump:  RVA 0x23B57FC → file offset 0x23B57FC
// We hook this to intercept role assignment
#define RPCSETROLE_OFFSET    0x23B57FC

// RoleTypes
#define ROLE_IMPOSTOR        1

using namespace zygisk;

// ── Globals ──────────────────────────────────────────────────────────────────
static uintptr_t g_base      = 0;   // libil2cpp.so base address
static bool      g_patched   = false;

// Original function pointer for RpcSetRole
// void RpcSetRole(PlayerControl* this, int16_t roleType, bool canOverride)
using RpcSetRole_t = void(*)(void*, int16_t, bool);
static RpcSetRole_t orig_RpcSetRole = nullptr;

// Our local PlayerControl pointer — set on first call
static void* g_localPlayer = nullptr;

// ── Helpers ──────────────────────────────────────────────────────────────────

// Read a typed value from an object at a given offset
template<typename T>
static T readField(void* obj, uintptr_t offset) {
    T val;
    memcpy(&val, (uint8_t*)obj + offset, sizeof(T));
    return val;
}

template<typename T>
static void writeField(void* obj, uintptr_t offset, T val) {
    memcpy((uint8_t*)obj + offset, &val, sizeof(T));
}

// ── Hook: RpcSetRole ─────────────────────────────────────────────────────────
// Signature: void PlayerControl::RpcSetRole(RoleTypes roleType, bool canOverrideRole)
// 'self' = the PlayerControl instance (this pointer)
// roleType arrives as int16
static void hook_RpcSetRole(void* self, int16_t roleType, bool canOverride) {
    LOGI("RpcSetRole called: self=%p roleType=%d canOverride=%d", self, roleType, canOverride);

    // Store local player on first sighting — the first RpcSetRole
    // call where self has PlayerId == 0 is usually the host/local player.
    // We'll store it and always patch it to Impostor.
    if (g_localPlayer == nullptr) {
        uint8_t pid = readField<uint8_t>(self, OFFSET_PLAYERID);
        LOGI("First RpcSetRole call — PlayerId=%d, storing as localPlayer candidate", pid);
        g_localPlayer = self;
    }

    // Check if this call is for OUR player
    if (self == g_localPlayer) {
        LOGI("This is our player! Forcing roleType from %d to %d (Impostor)", roleType, ROLE_IMPOSTOR);
        roleType   = ROLE_IMPOSTOR;
        canOverride = true;

        // Also directly write to the RoleType field in NetworkedPlayerInfo
        // PlayerControl has CachedPlayerData at 0x70
        void* cachedInfo = readField<void*>(self, 0x70);
        if (cachedInfo) {
            writeField<int16_t>(cachedInfo, OFFSET_ROLETYPE, ROLE_IMPOSTOR);
            LOGI("Also wrote Impostor directly to NetworkedPlayerInfo.RoleType");
        }
    }

    // Call the real function with (possibly modified) args
    orig_RpcSetRole(self, roleType, canOverride);
}

// ── Find libil2cpp base ───────────────────────────────────────────────────────
static uintptr_t getLibBase(const char* libname) {
    FILE* f = fopen("/proc/self/maps", "r");
    if (!f) return 0;
    char line[512];
    uintptr_t base = 0;
    while (fgets(line, sizeof(line), f)) {
        if (strstr(line, libname) && strstr(line, "r-xp")) {
            base = (uintptr_t)strtoull(line, nullptr, 16);
            break;
        }
    }
    fclose(f);
    return base;
}

// ── Setup thread ─────────────────────────────────────────────────────────────
static void* setup_thread(void*) {
    // Wait for libil2cpp to be loaded
    LOGI("Setup thread started, waiting for libil2cpp.so...");
    uintptr_t base = 0;
    for (int i = 0; i < 120 && base == 0; i++) {
        base = getLibBase("libil2cpp.so");
        if (!base) sleep(1);
    }

    if (!base) {
        LOGE("libil2cpp.so not found after 120s, giving up");
        return nullptr;
    }

    g_base = base;
    LOGI("libil2cpp.so base = 0x%lx", (unsigned long)base);

    // Calculate absolute address of RpcSetRole
    uintptr_t rpcSetRoleAddr = base + RPCSETROLE_OFFSET;
    LOGI("RpcSetRole absolute address = 0x%lx", (unsigned long)rpcSetRoleAddr);

    // Hook using Dobby
    int ret = DobbyHook(
        (void*)rpcSetRoleAddr,
        (void*)hook_RpcSetRole,
        (void**)&orig_RpcSetRole
    );

    if (ret == 0) {
        LOGI("✅ RpcSetRole hooked successfully!");
        g_patched = true;
    } else {
        LOGE("❌ DobbyHook failed with code %d", ret);
    }

    return nullptr;
}

// ── Zygisk Module ─────────────────────────────────────────────────────────────
class ImpostorModule : public ModuleBase {
public:
    void onLoad(Api* api, JNIEnv* env) override {
        this->api = api;
        this->env = env;
    }

    void preAppSpecialize(AppSpecializeArgs* args) override {
        auto package = env->GetStringUTFChars(args->nice_name, nullptr);
        LOGI("preAppSpecialize: %s", package);

        // Only activate for Among Us
        bool isAmongUs = (strstr(package, "com.innersloth.spacemafia") != nullptr);
        env->ReleaseStringUTFChars(args->nice_name, package);

        if (!isAmongUs) {
            api->setOption(DLCLOSE_MODULE_LIBRARY);
            return;
        }

        LOGI("Among Us detected — module active!");
    }

    void postAppSpecialize(const AppSpecializeArgs*) override {
        if (!g_patched) {
            pthread_t tid;
            pthread_create(&tid, nullptr, setup_thread, nullptr);
            pthread_detach(tid);
        }
    }

private:
    Api*    api = nullptr;
    JNIEnv* env = nullptr;
};

REGISTER_ZYGISK_MODULE(ImpostorModule)
