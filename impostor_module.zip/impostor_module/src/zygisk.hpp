#pragma once

#include <jni.h>
#include <cstdint>
#include <functional>

#define ZYGISK_API_VERSION 4

namespace zygisk {

struct AppSpecializeArgs {
    jint &uid;
    jint &gid;
    jintArray &gids;
    jint &runtime_flags;
    jint &rlimits;
    jint &mount_external;
    jstring &se_info;
    jstring &nice_name;
    jstring &instruction_set;
    jstring &app_data_dir;
    jboolean *const is_child_zygote;
    jboolean *const is_top_app;
    jobjectArray *const pkg_data_info_list;
    jobjectArray *const whitelisted_data_info_list;
    jboolean *const mount_data_dirs;
    jboolean *const mount_storage_dirs;
};

struct ServerSpecializeArgs {
    jint &uid;
    jint &gid;
    jintArray &gids;
    jint &runtime_flags;
    jint &rlimits;
    jlong &permitted_capabilities;
    jlong &effective_capabilities;
};

class Api;
class ModuleBase {
public:
    virtual void onLoad(Api*, JNIEnv*) {}
    virtual void preAppSpecialize(AppSpecializeArgs*) {}
    virtual void postAppSpecialize(const AppSpecializeArgs*) {}
    virtual void preServerSpecialize(ServerSpecializeArgs*) {}
    virtual void postServerSpecialize(const ServerSpecializeArgs*) {}
    virtual ~ModuleBase() = default;
};

class Api {
public:
    void setOption(int opt);
    bool exemptFd(int fd);
    int connectCompanion();
    void *getModuleDir();
    enum Options { DLCLOSE_MODULE_LIBRARY = (1 << 0) };
};

} // namespace zygisk

#define REGISTER_ZYGISK_MODULE(clazz) \
    extern "C" [[gnu::visibility("default")]] \
    void zygisk_module_entry(zygisk::Api *api, JNIEnv *env) { \
        auto *mod = new clazz(); \
        mod->onLoad(api, env); \
    }
